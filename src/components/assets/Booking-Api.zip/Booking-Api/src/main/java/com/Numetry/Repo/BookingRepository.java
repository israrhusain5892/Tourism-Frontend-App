package com.Numetry.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Numetry.Entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Long>{

}
