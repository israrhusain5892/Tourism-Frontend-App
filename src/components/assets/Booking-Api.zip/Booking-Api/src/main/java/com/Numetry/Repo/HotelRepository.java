package com.Numetry.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Numetry.Entity.Hotel;

public interface HotelRepository extends JpaRepository<Hotel, Long> {

}
